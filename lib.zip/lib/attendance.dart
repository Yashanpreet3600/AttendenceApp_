import 'package:flutter/material.dart';

class MarkAttendanceScreen extends StatefulWidget {
  final String className;

  const MarkAttendanceScreen({super.key, required this.className});

  @override
  State<MarkAttendanceScreen> createState() => _MarkAttendanceScreenState();
}

class _MarkAttendanceScreenState extends State<MarkAttendanceScreen> {
  // --- BRANDING ---
  final Color kalgidharBlue = const Color(0xFF002046);

  // --- STATE VARIABLES ---
  DateTime selectedDate = DateTime.now();
  String selectedTimeSlot = ""; // Holds the selected string from the list
  List<String> timeSlots = []; // Generated list

  // Mock Student List (Added names/rolls to fix previous missing data)
  List<Map<String, dynamic>> students = [
    {'id': '101', 'name': 'Rahul Kumar', 'roll': '2501', 'status': 'P'},
    {'id': '102', 'name': 'Sneha Gupta', 'roll': '2502', 'status': 'P'},
    {'id': '103', 'name': 'Amit Roy', 'roll': '2503', 'status': 'A'},
    {'id': '104', 'name': 'Priya Das', 'roll': '2504', 'status': 'P'},
    {'id': '105', 'name': 'Vikram Singh', 'roll': '2505', 'status': 'P'},
  ];

  @override
  void initState() {
    super.initState();
    _generateTimeSlots();
  }

  // --- LOGIC: GENERATE 9 SLOTS, 50 MIN GAP, START 9:00 ---
  void _generateTimeSlots() {
    timeSlots.clear();
    DateTime startTime = DateTime(2024, 1, 1, 9, 0); // Start at 9:00 AM

    for (int i = 0; i < 9; i++) {
      DateTime endTime = startTime.add(const Duration(minutes: 50));

      // Formatting time manually to avoid external dependencies like intl
      String startStr = "${_formatTime(startTime.hour)}:${_formatTime(startTime.minute)}";
      String endStr = "${_formatTime(endTime.hour)}:${_formatTime(endTime.minute)}";

      timeSlots.add("L${i + 1}: $startStr - $endStr");

      // The next class starts immediately after the previous one?
      // Or usually there is a break? Assuming continuous based on prompt.
      startTime = endTime;
    }
    // Set default to 1st slot
    selectedTimeSlot = timeSlots[0];
  }

  String _formatTime(int time) {
    return time.toString().padLeft(2, '0');
  }

  @override
  Widget build(BuildContext context) {
    // Calculate Summary
    int totalPresent = students.where((s) => s['status'] == 'P').length;
    int totalAbsent = students.length - totalPresent;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: kalgidharBlue,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Mark Attendance", style: TextStyle(color: Colors.white, fontSize: 18)),
            Text(widget.className, style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.check_circle),
            tooltip: "Submit",
            onPressed: () => _submitAttendance(),
          )
        ],
      ),
      body: Column(
        children: [
          // --- TOP CONTROL BAR (Date & Time) ---
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5, offset: const Offset(0, 2))],
            ),
            child: Column(
              children: [
                // ROW 1: Date & Time Selectors
                Row(
                  children: [
                    // --- 1. DATE SELECTOR (MANUAL) ---
                    Expanded(
                      flex: 4,
                      child: InkWell(
                        onTap: () => _selectDate(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey.shade300)
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.calendar_month, size: 18, color: kalgidharBlue),
                              const SizedBox(width: 8),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text("Date", style: TextStyle(fontSize: 10, color: Colors.grey)),
                                  Text(
                                    "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}",
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey[800]),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),

                    // --- 2. TIME SLOT SELECTOR (DROPDOWN) ---
                    Expanded(
                      flex: 6,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                            color: kalgidharBlue.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: kalgidharBlue.withOpacity(0.3))
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedTimeSlot,
                            isExpanded: true,
                            icon: Icon(Icons.arrow_drop_down, color: kalgidharBlue),
                            style: TextStyle(color: kalgidharBlue, fontWeight: FontWeight.bold, fontSize: 13),
                            onChanged: (String? newValue) {
                              setState(() {
                                selectedTimeSlot = newValue!;
                              });
                            },
                            items: timeSlots.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value, overflow: TextOverflow.ellipsis),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 12),

                // ROW 2: Mark All Toggle
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Mark All Present", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Transform.scale(
                      scale: 0.8,
                      child: Switch(
                        value: totalPresent == students.length,
                        activeColor: kalgidharBlue,
                        onChanged: (val) {
                          setState(() {
                            for (var s in students) {
                              s['status'] = val ? 'P' : 'A';
                            }
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // --- STUDENT LIST ---
          Expanded(
            child: ListView.builder(
              itemCount: students.length,
              padding: const EdgeInsets.only(bottom: 80, top: 10),
              itemBuilder: (context, index) {
                final student = students[index];
                bool isPresent = student['status'] == 'P';

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                      side: BorderSide(color: Colors.grey.shade200)
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                    leading: CircleAvatar(
                      backgroundColor: isPresent ? kalgidharBlue : Colors.red,
                      child: Text(
                        student['name'][0],
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                    title: Text(student['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text("Roll No: ${student['roll']}"),
                    trailing: InkWell(
                      onTap: () {
                        setState(() {
                          student['status'] = isPresent ? 'A' : 'P';
                        });
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        width: 90,
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                            color: isPresent ? Colors.green.withOpacity(0.1) : Colors.red.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: isPresent ? Colors.green : Colors.red)
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          isPresent ? "Present" : "Absent",
                          style: TextStyle(
                              color: isPresent ? Colors.green[700] : Colors.red[700],
                              fontWeight: FontWeight.bold,
                              fontSize: 12
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),

      // --- BOTTOM SUMMARY BAR ---
      bottomSheet: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, offset: const Offset(0, -5))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Total Students: ${students.length}", style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                Row(
                  children: [
                    Text("P: $totalPresent", style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 16)),
                    const SizedBox(width: 15),
                    Text("A: $totalAbsent", style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold, fontSize: 16)),
                  ],
                )
              ],
            ),
            ElevatedButton(
              onPressed: () => _submitAttendance(),
              style: ElevatedButton.styleFrom(
                backgroundColor: kalgidharBlue,
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text("SUBMIT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }

  // --- HELPER FUNCTIONS ---

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(primary: kalgidharBlue),
          ),
          child: child!,
        );
      },
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  void _submitAttendance() {
    int p = students.where((s) => s['status'] == 'P').length;
    int a = students.length - p;
    String dateStr = "${selectedDate.day}/${selectedDate.month}/${selectedDate.year}";

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Text("Confirm Submission", style: TextStyle(color: kalgidharBlue)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Class: ${widget.className}", style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text("Date: $dateStr"),
            Text("Slot: $selectedTimeSlot"),
            const Divider(),
            Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 16),
                const SizedBox(width: 5),
                Text("Present: $p"),
                const SizedBox(width: 20),
                const Icon(Icons.cancel, color: Colors.red, size: 16),
                const SizedBox(width: 5),
                Text("Absent: $a"),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Edit")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: kalgidharBlue),
            onPressed: () {
              Navigator.pop(ctx);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Attendance Submitted Successfully!"),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text("Confirm", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}