import 'package:flutter/material.dart';
import 'attendance.dart'; // Ensure this file exists
import 'test.dart'; // Ensure this file exists
import 'main.dart'; // For logout navigation

class FacultyDashboard extends StatefulWidget {
  const FacultyDashboard({super.key});

  @override
  State<FacultyDashboard> createState() => _FacultyDashboardState();
}

class _FacultyDashboardState extends State<FacultyDashboard> {
  // --- BRANDING COLORS ---
  final Color kalgidharBlue = const Color(0xFF002046);
  final Color kalgidharTeal = const Color(0xFF00796B);
  final Color alertRed = const Color(0xFFD32F2F);

  // --- STATE VARIABLES ---
  String selectedDepartment = 'Computer Science';
  String selectedClass = 'CS-A';
  String selectedSubject = 'Data Structures';

  // --- MOCK DATA ---

  // 1. Admin Notifications (Ring Notification)
  final List<String> adminNotifications = [
    "ADMIN: Urgent Staff Meeting at 2:00 PM today.",
    "ADMIN: Please submit internal marks by Friday.",
    "ADMIN: Holiday declared for tomorrow due to heavy rain."
  ];

  // 2. Simulated Missed Classes (Triggered if time table match fails)
  // This list simulates classes where attendance wasn't uploaded on time.
  List<Map<String, dynamic>> missedClasses = [
    {
      'class': 'CS-B',
      'subject': 'Web Development',
      'time': '10:00 AM - 11:00 AM',
      'date': 'Today',
      'status': 'Missing Attendance'
    }
  ];

  // 3. Dropdown Data
  final Map<String, List<String>> departmentData = {
    'Computer Science': ['CS-A', 'CS-B', 'BCA'],
    'Mechanical Eng': ['ME-A', 'ME-B'],
    'Commerce': ['B.Com-I', 'BBA-I'],
  };

  final Map<String, List<String>> subjectData = {
    'CS-A': ['Data Structures', 'Algorithms', 'Discrete Math'],
    'CS-B': ['Data Structures', 'Web Development'],
    'BCA':  ['Programming in C', 'Digital Electronics'],
    'ME-A': ['Thermodynamics', 'Fluid Mechanics'],
    'ME-B': ['Thermodynamics', 'Machine Design'],
    'B.Com-I': ['Financial Accounting', 'Business Law'],
    'BBA-I':   ['Principles of Mgmt', 'Micro Economics'],
  };

  // 4. Stats
  final Map<String, Map<String, dynamic>> lectureStats = {
    'CS-A': {'scheduled': 45, 'delivered': 38, 'extra': 2},
    'CS-B': {'scheduled': 40, 'delivered': 30, 'extra': 0},
    'BCA': {'scheduled': 50, 'delivered': 45, 'extra': 5},
    'ME-A': {'scheduled': 42, 'delivered': 40, 'extra': 1},
    'ME-B': {'scheduled': 42, 'delivered': 35, 'extra': 0},
    'B.Com-I': {'scheduled': 60, 'delivered': 55, 'extra': 3},
    'BBA-I': {'scheduled': 55, 'delivered': 50, 'extra': 2},
  };

  final List<String> studentList = [
    'Rahul Kumar (101)', 'Sneha Gupta (102)', 'Amit Roy (103)', 'Priya Das (104)'
  ];

  @override
  Widget build(BuildContext context) {
    var stats = lectureStats[selectedClass] ?? {'scheduled': 0, 'delivered': 0, 'extra': 0};

    return Scaffold(
      backgroundColor: Colors.grey[50],
      drawer: _buildSideBar(context),
      appBar: AppBar(
        backgroundColor: kalgidharBlue,
        title: const Text('Faculty Dashboard', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          // --- BELL NOTIFICATION ICON ---
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.notifications),
                onPressed: () => _showNotificationDialog(context),
              ),
              if (adminNotifications.isNotEmpty)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(6)),
                    constraints: const BoxConstraints(minWidth: 14, minHeight: 14),
                    child: Text('${adminNotifications.length}', style: const TextStyle(color: Colors.white, fontSize: 8), textAlign: TextAlign.center),
                  ),
                )
            ],
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // --- 1. MISSED CLASS ALERT (NEW) ---
            if (missedClasses.isNotEmpty) ...[
              _buildSectionHeader("⚠️ Action Required"),
              Card(
                color: Colors.red[50],
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: alertRed.withOpacity(0.3))),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Icon(Icons.warning_amber_rounded, color: alertRed, size: 30),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Missed Class Detected!", style: TextStyle(fontWeight: FontWeight.bold, color: alertRed, fontSize: 16)),
                                const SizedBox(height: 4),
                                Text("Attendance not uploaded for ${missedClasses[0]['class']} (${missedClasses[0]['subject']}) on time.", style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: () => _showResolveMissedClassDialog(context, 0),
                          icon: const Icon(Icons.edit_note, size: 16),
                          label: const Text("Provide Reason"),
                          style: ElevatedButton.styleFrom(backgroundColor: alertRed, foregroundColor: Colors.white),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // --- 2. SELECTION FILTERS ---
            _buildSectionHeader("Class & Subject Selection"),
            Row(
              children: [
                Expanded(
                  child: _buildDropdown(
                    value: selectedDepartment,
                    items: departmentData.keys.toList(),
                    onChanged: (val) {
                      setState(() {
                        selectedDepartment = val!;
                        selectedClass = departmentData[val]!.first;
                        selectedSubject = subjectData[selectedClass]!.first;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _buildDropdown(
                    value: selectedClass,
                    items: departmentData[selectedDepartment]!,
                    onChanged: (val) => setState(() {
                      selectedClass = val!;
                      selectedSubject = subjectData[selectedClass]!.first;
                    }),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kalgidharBlue.withOpacity(0.5))
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedSubject,
                  isExpanded: true,
                  icon: Icon(Icons.book, color: kalgidharBlue),
                  onChanged: (val) => setState(() => selectedSubject = val!),
                  items: subjectData[selectedClass]!.map((item) => DropdownMenuItem(value: item, child: Text(item, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w600, color: kalgidharBlue)))).toList(),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // --- 3. LECTURE OVERVIEW ---
            _buildSectionHeader("Lecture Overview"),
            Row(
              children: [
                _buildStatBox("Scheduled", stats['scheduled'].toString(), Colors.blueGrey),
                const SizedBox(width: 10),
                _buildStatBox("Delivered", stats['delivered'].toString(), kalgidharBlue),
                const SizedBox(width: 10),
                _buildStatBox("Extra", stats['extra'].toString(), Colors.orange[800]!),
              ],
            ),
            const SizedBox(height: 20),

            // --- 4. COMMUNICATION ---
            _buildSectionHeader("Communication"),
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.blue.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                  child: const Icon(Icons.translate, color: Colors.blue),
                ),
                title: const Text("Send Message"),
                subtitle: const Text("Notify Students or Parents"),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => _showComposeMessageDialog(context),
              ),
            ),
            const SizedBox(height: 20),

            // --- 5. DATA ENTRY & ACTIONS ---
            _buildSectionHeader("Data Entry & Actions"),
            Row(
              children: [
                Expanded(
                  child: _actionButton(
                    context, Icons.cloud_upload_outlined, 'Upload\nAttendance', kalgidharBlue,
                        () => _showUploadAttendanceDialog(context),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _actionButton(
                    context, Icons.post_add, 'Upload\nTest (17)', kalgidharTeal,
                        () => _showUploadTestDialog(context),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _actionButton(
                    context, Icons.add_alarm, 'Extra\nClass', Colors.orange[800]!,
                        () => _showExtraLectureDialog(context),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // --- 6. REPORTS ---
            _buildSectionHeader("Reports"),
            Row(
              children: [
                Expanded(child: _buildDownloadButton(context, "Attendance Report", Icons.grid_on, Colors.green[700]!)),
                const SizedBox(width: 15),
                Expanded(child: _buildDownloadButton(context, "Test Report", Icons.assessment, kalgidharBlue)),
              ],
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  // ==========================================
  // SIDEBAR
  // ==========================================
  Widget _buildSideBar(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: kalgidharBlue),
            accountName: const Text("Dr. A. Sharma"),
            accountEmail: const Text("Faculty ID: 1002"),
            currentAccountPicture: const CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 40, color: Color(0xFF002046)),
            ),
          ),
          ListTile(
            leading: Icon(Icons.dashboard, color: kalgidharBlue),
            title: const Text("Dashboard"),
            onTap: () => Navigator.pop(context),
          ),
          ListTile(
            leading: Icon(Icons.calendar_month, color: kalgidharBlue),
            title: const Text("Time Table"),
            onTap: () {
              Navigator.pop(context);
              _showTimeTable(context);
            },
          ),
          ListTile(
            leading: Icon(Icons.translate, color: kalgidharBlue),
            title: const Text("Messages "),
            onTap: () {
              Navigator.pop(context);
              _showComposeMessageDialog(context);
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red),
            title: const Text("Logout", style: TextStyle(color: Colors.red)),
            onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginScreen())),
          ),
        ],
      ),
    );
  }

  // ==========================================
  // DIALOGS & LOGIC
  // ==========================================

  // --- 1. ADMIN NOTIFICATIONS DIALOG ---
  void _showNotificationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Row(
          children: [
            const Icon(Icons.notifications_active, color: Colors.red),
            const SizedBox(width: 10),
            Text("Admin Alerts", style: TextStyle(color: kalgidharBlue)),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: adminNotifications.isEmpty
              ? const Text("No new notifications.")
              : ListView.builder(
            shrinkWrap: true,
            itemCount: adminNotifications.length,
            itemBuilder: (context, index) {
              return ListTile(
                leading: const Icon(Icons.circle, size: 10, color: Colors.red),
                title: Text(adminNotifications[index], style: const TextStyle(fontSize: 14)),
                contentPadding: EdgeInsets.zero,
              );
            },
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Close")),
          if (adminNotifications.isNotEmpty)
            TextButton(
              onPressed: () {
                setState(() => adminNotifications.clear());
                Navigator.pop(ctx);
              },
              child: const Text("Clear All"),
            )
        ],
      ),
    );
  }

  // --- 2. MISSED CLASS RESOLUTION DIALOG (Reason + Camera) ---
  void _showResolveMissedClassDialog(BuildContext context, int index) {
    final reasonController = TextEditingController();
    bool imageAttached = false;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
            builder: (context, setState) {
              return AlertDialog(
                title: const Text("Explain Absence", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Why was the attendance not uploaded?", style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      TextField(
                        controller: reasonController,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: "e.g., On Leave, Technical Issue, OD...",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text("Attach Proof (Optional):", style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      ElevatedButton.icon(
                        onPressed: () {
                          setState(() => imageAttached = !imageAttached);
                        },
                        icon: Icon(imageAttached ? Icons.check : Icons.camera_alt),
                        label: Text(imageAttached ? "Photo Attached" : "Open Camera"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: imageAttached ? Colors.green : Colors.grey[200],
                          foregroundColor: imageAttached ? Colors.white : Colors.black,
                        ),
                      )
                    ],
                  ),
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: kalgidharBlue, foregroundColor: Colors.white),
                    onPressed: () {
                      if (reasonController.text.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please enter a reason."), backgroundColor: Colors.red));
                        return;
                      }
                      // Resolve logic
                      Navigator.pop(ctx);
                      setState(() {
                        missedClasses.removeAt(index);
                      });
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Explanation Submitted to Admin."), backgroundColor: Colors.green));
                    },
                    child: const Text("Submit"),
                  )
                ],
              );
            }
        );
      },
    );
  }

  // --- 3. EXTRA LECTURE DIALOG ---
  void _showExtraLectureDialog(BuildContext context) {
    final dateController = TextEditingController(text: "${DateTime.now().day}/${DateTime.now().month}/${DateTime.now().year}");
    final timeController = TextEditingController();
    final roomController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Mark Extra Lecture", style: TextStyle(color: kalgidharBlue)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: dateController, decoration: const InputDecoration(labelText: "Date", hintText: "DD/MM/YYYY", prefixIcon: Icon(Icons.calendar_today))),
              TextField(controller: timeController, decoration: const InputDecoration(labelText: "Timing", hintText: "e.g. 10:00 AM", prefixIcon: Icon(Icons.access_time))),
              TextField(controller: roomController, decoration: const InputDecoration(labelText: "Room No", hintText: "e.g. LT-1", prefixIcon: Icon(Icons.meeting_room))),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange[800], foregroundColor: Colors.white),
            onPressed: () {
              if (dateController.text.isEmpty || timeController.text.isEmpty || roomController.text.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("All fields are required"), backgroundColor: Colors.red));
                return;
              }
              setState(() {
                lectureStats[selectedClass]!['extra'] += 1;
                lectureStats[selectedClass]!['delivered'] += 1;
              });
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Extra Lecture Added!"), backgroundColor: Colors.green));
            },
            child: const Text("Confirm"),
          )
        ],
      ),
    );
  }

  // --- 4. MESSAGE DIALOG ---
  void _showComposeMessageDialog(BuildContext context) {
    String recipientScope = 'Whole Class';
    String recipientType = 'Student';
    String selectedLanguage = 'English';
    bool imageAttached = false;
    final messageController = TextEditingController();

    showDialog(
        context: context,
        builder: (ctx) {
          return StatefulBuilder(
              builder: (context, setState) {
                return AlertDialog(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  title: Text("Send Message", style: TextStyle(color: kalgidharBlue, fontWeight: FontWeight.bold)),
                  content: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(children: [
                          Expanded(child: RadioListTile<String>(title: const Text("Students", style: TextStyle(fontSize: 14)), value: 'Student', groupValue: recipientType, contentPadding: EdgeInsets.zero, onChanged: (val) => setState(() => recipientType = val!))),
                          Expanded(child: RadioListTile<String>(title: const Text("Parents", style: TextStyle(fontSize: 14)), value: 'Parent', groupValue: recipientType, contentPadding: EdgeInsets.zero, onChanged: (val) => setState(() => recipientType = val!))),
                        ]),
                        const Divider(),
                        DropdownButtonFormField<String>(value: recipientScope, isExpanded: true, decoration: const InputDecoration(labelText: "Recipient Group", border: OutlineInputBorder()), items: ['Whole Class', 'Specific Student'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (val) => setState(() => recipientScope = val!)),
                        const SizedBox(height: 15),
                        TextField(controller: messageController, maxLines: 4, decoration: InputDecoration(hintText: "Type in English...", border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), filled: true, fillColor: Colors.grey[50])),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            IconButton(onPressed: () => setState(() => imageAttached = !imageAttached), icon: Icon(imageAttached ? Icons.check_circle : Icons.camera_alt, color: imageAttached ? Colors.green : Colors.grey)),
                            Expanded(child: Container(height: 40, padding: const EdgeInsets.symmetric(horizontal: 10), decoration: BoxDecoration(color: Colors.blue[50], borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.blue.withOpacity(0.3))), child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: selectedLanguage, icon: const Icon(Icons.translate, size: 16), items: ['English', 'Hindi', 'Punjabi'].map((lang) => DropdownMenuItem(value: lang, child: Text(lang, style: const TextStyle(fontSize: 13)))).toList(), onChanged: (val) => setState(() => selectedLanguage = val!))))),
                          ],
                        ),
                      ],
                    ),
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
                    ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: kalgidharBlue, foregroundColor: Colors.white), onPressed: () { Navigator.pop(ctx); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Sent to $recipientScope"), backgroundColor: kalgidharBlue)); }, child: const Text("Send"))
                  ],
                );
              }
          );
        }
    );
  }

  // ==========================================
  // WIDGET HELPERS
  // ==========================================

  Widget _buildStatBox(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.2)),
            boxShadow: [BoxShadow(color: Colors.grey.withOpacity(0.1), blurRadius: 4, offset: const Offset(0, 2))]
        ),
        child: Column(
          children: [
            Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[600], fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(padding: const EdgeInsets.only(bottom: 10, top: 5), child: Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey[800])));
  }

  Widget _buildDropdown({required String value, required List<String> items, required Function(String?) onChanged}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.grey.shade300)),
      child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: value, isExpanded: true, icon: Icon(Icons.arrow_drop_down, color: kalgidharBlue), onChanged: onChanged, items: items.map((item) => DropdownMenuItem(value: item, child: Text(item, overflow: TextOverflow.ellipsis))).toList())),
    );
  }

  Widget _actionButton(BuildContext context, IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
        onTap: onTap,
        child: Container(
            height: 85,
            decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withOpacity(0.3))
            ),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 26, color: color),
                  const SizedBox(height: 4),
                  Text(label, textAlign: TextAlign.center, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11))
                ]
            )
        )
    );
  }

  Widget _buildDownloadButton(BuildContext context, String label, IconData icon, Color color) {
    return ElevatedButton(
        onPressed: () { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Downloading $label..."))); },
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.white, foregroundColor: color, elevation: 2,
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: color.withOpacity(0.1)))
        ),
        child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [Icon(icon, size: 20), const SizedBox(width: 8), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold))]
        )
    );
  }

  // --- OTHERS ---
  void _showTimeTable(BuildContext context) {
    showModalBottomSheet(context: context, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))), builder: (ctx) => const SizedBox(height: 200, child: Center(child: Text("Time Table Placeholder"))));
  }

  void _showUploadTestDialog(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => MarkTestScreen(className: "$selectedClass - $selectedSubject")));
  }

  void _showUploadAttendanceDialog(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (context) => MarkAttendanceScreen(className: "$selectedClass - $selectedSubject")));
  }
}