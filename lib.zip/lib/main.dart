import 'package:flutter/material.dart';
import 'dart:async'; // Required for the Timer
import 'student_dashboard.dart'; // <--- IMPORT ADDED HERE
import 'faculity.dart';
import 'admin.dart';
void main() => runApp(LoginApp());

class LoginApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      // CHANGE 1: Start with SplashScreen instead of LoginScreen
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- NEW SPLASH SCREEN WIDGET ---
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // CHANGE 2: Wait 3 seconds, then navigate to LoginScreen
    Timer(Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Using your Brand Navy Blue color
      backgroundColor: const Color(0xFF002046),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo inside a white circle for better visibility
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              child: Image.asset('assets/images/12.png', height: 100, width: 100),
            ),
            SizedBox(height: 200),
            Text(
              'Akal University',
              style: TextStyle(
                color: Colors.white,
                fontSize: 42 ,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Value Based Education',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 32,
              ),
            ),
            SizedBox(height: 50),
            // Loading Indicator
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

// --- YOUR EXISTING LOGIN SCREEN ---
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();

  // --- COLORS ---
  final Color kalgidharBlue = const Color(0xFF002046);
  final Color kalgidharTeal = const Color(0xFF00796B);
  // --------------

  String selectedRole = 'Student';
  bool rememberMe = true;
  String selectedLanguage = 'English';
  bool _isPasswordVisible = false;

  final usernameController = TextEditingController();
  final passwordController = TextEditingController();

  final roleKeys = ['Student', 'Faculty', 'Admin'];
  final languages = ['English', 'Punjabi', 'Hindi'];

  final Map<String, Map<String, String>> _localizedValues = {
    'English': {
      // Contemplate and reflect upon knowledge, and you will become a benefactor to others.
      'subtitle': 'True learning induces in the mind service to mankind.',
      'username': 'User Name',
      'password': 'Password',
      'remember': 'Remember me',
      'pref_lang': 'Preferred language',
      'login': 'Log In',
      'Student': 'Student',
      'Faculty': 'Faculty',
      'Teacher': 'Teacher',
      'empty_user': 'Please enter User Name',
      'empty_pass': 'Please enter Password',
    },
    'Punjabi': {
      'subtitle': 'ਗਿਆਨ ਨੂੰ ਵਿਚਾਰੋ ਅਤੇ ਚਿੰਤਨ ਕਰੋ, ਅਤੇ ਤੁਸੀਂ ਦੂਜਿਆਂ ਦੇ ਪਰਉਪਕਾਰੀ ਬਣ ਜਾਓਗੇ।',
      'username': 'ਉਪਭੋਗਤਾ ਨਾਮ',
      'password': 'ਪਾਸਵਰਡ',
      'remember': 'ਮੈਨੂੰ ਯਾਦ ਰੱਖੋ',
      'pref_lang': 'ਪਸੰਦੀਦਾ ਭਾਸ਼ਾ',
      'login': 'ਲੌਗ ਇਨ',
      'Student': 'ਵਿਦਿਆਰਥੀ',
      'Faculty': 'ਫੈਕਲਟੀ',
      'Teacher': 'ਅਧਿਆਪਕ',
      'empty_user': 'ਕਿਰਪਾ ਕਰਕੇ ਉਪਭੋਗਤਾ ਨਾਮ ਦਰਜ ਕਰੋ',
      'empty_pass': 'ਕਿਰਪਾ ਕਰਕੇ ਪਾਸਵਰਡ ਦਰਜ ਕਰੋ',
    },
    'Hindi': {
      'subtitle': 'ज्ञान पर चिंतन और मनन करें, और आप दूसरों के लिए परोपकारी बन जाएंगे।',
      'username': 'उपयोगकर्ता नाम',
      'password': 'पासवर्ड',
      'remember': 'मुझे याद रखें',
      'pref_lang': 'पसंदीदा भाषा',
      'login': 'लॉग इन',
      'Student': 'छात्र',
      'Faculty': 'संकाय',
      'Teacher': 'शिक्षक',
      'empty_user': 'कृपया उपयोगकर्ता नाम दर्ज करें',
      'empty_pass': 'कृपया पासवर्ड दर्ज करें',
    },
  };

  String getTrans(String key) {
    return _localizedValues[selectedLanguage]?[key] ?? key;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // HEADER
              Container(
                color: kalgidharBlue,
                padding: EdgeInsets.all(16),
                width: double.infinity,
                child: Column(
                  children: [
                    Text(
                      // ਵਿਦਿਆ ਵੀਚਾਰੀ ਤਾਂ ਪਰਉਪਕਾਰੀ ॥
                      '',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 4),
                    Text(
                      getTrans('subtitle'),
                      style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                          fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
// Logo inside a white circle for better visibility
              Container(
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: Image.asset('assets/images/12.png', height: 100, width: 100),
              ),
              SizedBox(height: 50),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // USERNAME
                      TextFormField(
                        controller: usernameController,
                        decoration: InputDecoration(
                          labelText: getTrans('username'),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return getTrans('empty_user');
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 12),

                      // PASSWORD
                      TextFormField(
                        controller: passwordController,
                        obscureText: !_isPasswordVisible,
                        decoration: InputDecoration(
                          labelText: getTrans('password'),
                          border: OutlineInputBorder(),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _isPasswordVisible
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Colors.grey,
                            ),
                            onPressed: () {
                              setState(() {
                                _isPasswordVisible = !_isPasswordVisible;
                              });
                            },
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return getTrans('empty_pass');
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 16),

                      // ROLES
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: roleKeys.map((roleKey) {
                          final isSelected = selectedRole == roleKey;
                          return ElevatedButton(
                            onPressed: () => setState(() => selectedRole = roleKey),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: isSelected ? kalgidharBlue : Colors.grey[300],
                              foregroundColor: isSelected ? Colors.white : Colors.black,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20)),
                            ),
                            child: Text(getTrans(roleKey)),
                          );
                        }).toList(),
                      ),

                      SizedBox(height: 10),

                      // REMEMBER ME
                      Row(
                        children: [
                          Switch(
                            value: rememberMe,
                            activeColor: kalgidharTeal,
                            onChanged: (val) => setState(() => rememberMe = val),
                          ),
                          Text(getTrans('remember')),
                        ],
                      ),

                      // PREFERRED LANGUAGE
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(
                            getTrans('pref_lang'),
                            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.grey[700]),
                          ),
                          SizedBox(width: 10),
                          DropdownButton<String>(
                            value: selectedLanguage,
                            underline: Container(height: 2, color: kalgidharBlue),
                            onChanged: (val) => setState(() => selectedLanguage = val!),
                            items: languages.map((lang) => DropdownMenuItem(
                              value: lang,
                              child: Text(lang),
                            )).toList(),
                          ),
                        ],
                      ),

                      SizedBox(height: 20),

                      // LOGIN BUTTON
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () {
                            if (_formKey.currentState!.validate()) {

                              // --- CONNECTION LOGIC ADDED HERE ---
                              if (selectedRole == 'Student') {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(builder: (context) => StudentDashboard()),
                                );
                              } else if (selectedRole == "Faculty"){
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(builder: (context) => FacultyDashboard()),
                                );
                              } else {
                                Navigator.pushReplacement(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => AdminDashboard()),
                                );
                              }
                              // -----------------------------------

                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: kalgidharBlue,
                            padding: EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                          ),
                          child: Text(
                            getTrans('login'),
                            style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}