import 'package:flutter/material.dart';
import 'main.dart';
// --- ENTRY POINT ---


// --- STUDENT DASHBOARD CODE ---
class StudentDashboard extends StatefulWidget {
  @override
  _StudentDashboardState createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> {
  // --- BRANDING COLORS ---
  final Color kalgidharBlue = const Color(0xFF002046);
  final Color kalgidharTeal = const Color(0xFF00796B);

  // --- STATE ---
  String selectedSubjectCode = 'MAT-101';

  // --- DATA: FACULTY MESSAGES ---
  final List<Map<String, String>> facultyMessages = [
    {'sender': 'Dr. Sharma (CS Dept)', 'title': 'Monday Test Syllabus', 'body': 'Test covers Unit 3.', 'time': '2 hrs ago', 'priority': 'High'},
    {'sender': 'Admin Office', 'title': 'Holiday Notice', 'body': 'College closed on Friday.', 'time': '2 days ago', 'priority': 'Normal'},
  ];

  // --- DATA: LEAVE HISTORY ---
  final List<Map<String, String>> leaveHistory = [
    {'date': '20 Nov 2025', 'reason': 'Viral Fever', 'status': 'Approved', 'remark': 'Take care'},
    {'date': '10 Nov 2025', 'reason': 'Family Function', 'status': 'Rejected', 'remark': 'Exams near'},
    {'date': '05 Nov 2025', 'reason': 'Urgent Work', 'status': 'Pending', 'remark': 'Under review'},
  ];

  // --- DATA: SUBJECTS ---
  final List<Map<String, dynamic>> allSubjects = [
    {'name': 'Mathematics', 'code': 'MAT-101', 'total': 50, 'attended': 45},
    {'name': 'Computer Science', 'code': 'CS-202', 'total': 40, 'attended': 38},
    {'name': 'Physics', 'code': 'PHY-301', 'total': 40, 'attended': 25}, // Low Attendance Example
    {'name': 'English Literature', 'code': 'ENG-104', 'total': 30, 'attended': 28},
  ];

  // --- DATA: DETAILED ATTENDANCE LOGS ---
  final Map<String, List<Map<String, String>>> attendanceLogs = {
    'MAT-101': [{'date': '24 Nov', 'status': 'Present'}, {'date': '23 Nov', 'status': 'Present'}],
    'CS-202': [{'date': '24 Nov', 'status': 'Present'}, {'date': '23 Nov', 'status': 'Absent'}],
    'PHY-301': [{'date': '24 Nov', 'status': 'Absent'}, {'date': '23 Nov', 'status': 'Absent'}],
    'ENG-104': [{'date': '24 Nov', 'status': 'Present'}],
  };

  // --- DATA: TEST SCORES ---
  final Map<String, List<Map<String, dynamic>>> testScores = {
    'MAT-101': [{'test': 'Test 1', 'score': 15.0}, {'test': 'Test 2', 'score': 16.5}],
    'CS-202': [{'test': 'Test 1', 'score': 17.0}, {'test': 'Test 2', 'score': 16.0}],
    'PHY-301': [{'test': 'Test 1', 'score': 6.0}, {'test': 'Test 2', 'score': 7.5}], // Low Marks Example
    'ENG-104': [{'test': 'Test 1', 'score': 12.0}],
  };

  // --- DATA: TIMETABLE ---
  final List<Map<String, String>> timeTable = [
    {'time': '09:00 - 10:00', 'subject': 'Mathematics (MAT-101)', 'room': '201'},
    {'time': '10:00 - 11:00', 'subject': 'Physics (PHY-301)', 'room': 'Lab 2'},
    {'time': '11:00 - 11:30', 'subject': 'Break', 'room': '-'},
    {'time': '11:30 - 12:30', 'subject': 'Computer Science (CS-202)', 'room': 'Lab 1'},
    {'time': '12:30 - 01:30', 'subject': 'English (ENG-104)', 'room': '203'},
  ];

  @override
  Widget build(BuildContext context) {
    // Calculations
    var currentSubjectData = allSubjects.firstWhere((e) => e['code'] == selectedSubjectCode);
    double subPercentage = currentSubjectData['total'] == 0 ? 0 : currentSubjectData['attended'] / currentSubjectData['total'];

    List<Map<String, dynamic>> subjectTests = testScores[selectedSubjectCode] ?? [];
    double totalScoreSum = 0;
    for (var t in subjectTests) totalScoreSum += t['score'];
    double averageScore = subjectTests.isEmpty ? 0 : totalScoreSum / subjectTests.length;
    double testPercentage = averageScore / 17.0;

    int overallTotal = 0;
    int overallAttended = 0;
    for (var sub in allSubjects) {
      overallTotal += sub['total'] as int;
      overallAttended += sub['attended'] as int;
    }
    double overallPercentage = overallTotal == 0 ? 0 : overallAttended / overallTotal;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      drawer: _buildSideBar(context),
      appBar: AppBar(
        backgroundColor: kalgidharBlue,
        title: const Text('AttendEase Student', style: TextStyle(color: Colors.white)),
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
              icon: const Icon(Icons.notifications_active_outlined),
              onPressed: () => _showWarnings(context) // Updated function name
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome & Apply Leave
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Hello, Student", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Text("ID: STU-2025-008", style: TextStyle(color: Colors.grey)),
                  ],
                ),
                ElevatedButton.icon(
                  onPressed: () => _showApplyLeaveDialog(context),
                  icon: const Icon(Icons.add_circle_outline, size: 18),
                  label: const Text("Apply Leave"),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orange[700], foregroundColor: Colors.white),
                ),
              ],
            ),
            const SizedBox(height: 20),

            _buildSectionTitle("Academic Overview"),
            _buildAttendanceCard("Overall Attendance", "All Subjects", overallPercentage, overallAttended, overallTotal, true),

            const SizedBox(height: 25), const Divider(), const SizedBox(height: 10),

            _buildSectionTitle("Subject Details"),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: kalgidharBlue.withOpacity(0.3))),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedSubjectCode,
                  isExpanded: true,
                  onChanged: (val) => setState(() => selectedSubjectCode = val!),
                  items: allSubjects.map((s) => DropdownMenuItem(value: s['code'] as String, child: Text("${s['code']} - ${s['name']}"))).toList(),
                ),
              ),
            ),
            const SizedBox(height: 15),

            _buildAttendanceCard("Subject Attendance", currentSubjectData['name'], subPercentage, currentSubjectData['attended'], currentSubjectData['total'], false),

            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: () => _showAttendanceLogSheet(context, currentSubjectData['name']),
                icon: const Icon(Icons.calendar_month, size: 18),
                label: const Text("View Day-by-Day Attendance"),
                style: TextButton.styleFrom(foregroundColor: kalgidharBlue),
              ),
            ),

            const SizedBox(height: 10),

            _buildTestPerformanceCard(currentSubjectData['name'], averageScore, testPercentage),

            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: () => _showTestLogSheet(context, currentSubjectData['name'], subjectTests),
                icon: const Icon(Icons.assignment, size: 18),
                label: const Text("View All Test Scores"),
                style: TextButton.styleFrom(foregroundColor: Colors.deepPurple),
              ),
            ),

            const SizedBox(height: 20),

            Card(
              color: const Color(0xFFE3F2FD),
              elevation: 2,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: Icon(Icons.mail_outline, color: kalgidharBlue),
                title: const Text("Faculty Messages"),
                subtitle: const Text("Check inbox or send a query"),
                trailing: Icon(Icons.arrow_forward, color: kalgidharBlue),
                onTap: () => _showMessageCenter(context),
              ),
            )
          ],
        ),
      ),
    );
  }

  // ==========================================
  // SIDEBAR (DRAWER)
  // ==========================================
  Widget _buildSideBar(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: kalgidharBlue),
            accountName: const Text("Student Name"),
            accountEmail: const Text("ID: 2025-008"),
            currentAccountPicture: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.person, size: 40, color: Color(0xFF002046))),
          ),
          ListTile(
            leading: const Icon(Icons.dashboard_outlined), title: const Text("Dashboard"),
            onTap: () => Navigator.pop(context),
          ),

          // --- UPDATED: Timetable in Sidebar ---
          ListTile(
            leading: const Icon(Icons.calendar_view_day_outlined), title: const Text("Timetable"),
            onTap: () {
              Navigator.pop(context);
              _showTimeTableSheet(context);
            },
          ),

          ListTile(
            leading: const Icon(Icons.fact_check_outlined), title: const Text("Leave Status"),
            onTap: () {
              Navigator.pop(context);
              _showLeaveStatusSheet(context);
            },
          ),

          // --- UPDATED: Renamed to Notifications (No SMS) ---
          ListTile(
            leading: const Icon(Icons.notifications_none, color: Colors.orange),
            title: const Text("Notifications"),
            onTap: () {
              Navigator.pop(context);
              _showWarnings(context);
            },
          ),

          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.red), title: const Text("Logout", style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                      (Route<dynamic> route) => false
              );
            },
          ),
        ],
      ),
    );
  }

  // ==========================================
  // UPDATED: WARNINGS (Removed Parent SMS)
  // ==========================================
  void _showWarnings(BuildContext context) {
    List<Map<String, dynamic>> lowAttendanceSubjects = allSubjects.where((sub) {
      double pct = sub['attended'] / sub['total'];
      return pct < 0.75;
    }).toList();

    List<String> lowMarkSubjects = [];
    testScores.forEach((key, tests) {
      for (var t in tests) {
        if (t['score'] < 8.5) {
          lowMarkSubjects.add("$key (${t['test']})");
        }
      }
    });

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Alerts & Warnings", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kalgidharBlue)),
              const Text("Items requiring your immediate attention.", style: TextStyle(fontSize: 12, color: Colors.grey)),
              const Divider(),
              Expanded(
                child: ListView(
                  children: [
                    if (lowAttendanceSubjects.isEmpty && lowMarkSubjects.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(20.0),
                        child: Center(child: Text("No alerts! You are doing great.", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold))),
                      ),

                    ...lowAttendanceSubjects.map((sub) => _buildAlertTile(
                        "Low Attendance: ${sub['name']}",
                        "Current: ${(sub['attended']/sub['total']*100).toInt()}%. Required: 75%",
                        Icons.warning, Colors.red
                    )),

                    ...lowMarkSubjects.map((sub) => _buildAlertTile(
                        "Score Improvement Needed",
                        "Subject: $sub. Score is below 50%.",
                        Icons.trending_down, Colors.orange
                    )),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAlertTile(String title, String subtitle, IconData icon, Color color) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: color.withOpacity(0.1),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: color.withOpacity(0.3))),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: color)),
        subtitle: Text(subtitle),
      ),
    );
  }

  // ==========================================
  // UPDATED: TIMETABLE SHEET
  // ==========================================
  void _showTimeTableSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Daily Timetable", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kalgidharBlue)),
                  Chip(label: Text("Wednesday"), backgroundColor: Colors.blue[100]),
                ],
              ),
              const Divider(),
              Expanded(
                child: ListView.separated(
                  itemCount: timeTable.length,
                  separatorBuilder: (c, i) => const Divider(height: 1),
                  itemBuilder: (ctx, i) {
                    var item = timeTable[i];
                    bool isBreak = item['subject'] == 'Break';
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(color: isBreak ? Colors.orange[100] : Colors.grey[200], borderRadius: BorderRadius.circular(8)),
                        child: Text(item['time']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                      ),
                      title: Text(item['subject']!, style: TextStyle(fontWeight: FontWeight.bold, color: isBreak ? Colors.orange : Colors.black87)),
                      trailing: Text(item['room']!, style: const TextStyle(color: Colors.grey)),
                    );
                  },
                ),
              )
            ],
          ),
        );
      },
    );
  }

  // ==========================================
  // UPDATED: APPLY LEAVE WITH CAMERA
  // ==========================================
  void _showApplyLeaveDialog(BuildContext context) {
    final List<String> recipients = ['Mentor', 'Subject Teacher', 'HOD', 'Class In-charge'];
    String selectedRecipient = recipients[0];
    TextEditingController dateController = TextEditingController();

    // Simulate File selection
    bool isFileAttached = false;

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              title: Text("Apply for Leave", style: TextStyle(color: kalgidharBlue, fontWeight: FontWeight.bold)),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      value: selectedRecipient,
                      decoration: const InputDecoration(labelText: 'To Whom', border: OutlineInputBorder()),
                      items: recipients.map((val) => DropdownMenuItem(value: val, child: Text(val))).toList(),
                      onChanged: (val) => setState(() => selectedRecipient = val!),
                    ),
                    const SizedBox(height: 15),
                    TextField(
                      controller: dateController,
                      decoration: const InputDecoration(labelText: 'Date', prefixIcon: Icon(Icons.calendar_today), border: OutlineInputBorder()),
                      onTap: () async {
                        DateTime? picked = await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime(2026));
                        if(picked!=null) dateController.text = "${picked.day}/${picked.month}/${picked.year}";
                      },
                    ),
                    const SizedBox(height: 15),
                    const TextField(maxLines: 2, decoration: InputDecoration(labelText: "Reason", border: OutlineInputBorder())),

                    const SizedBox(height: 15),

                    // --- CAMERA ATTACHMENT UI ---
                    InkWell(
                      onTap: () {
                        setState(() {
                          isFileAttached = !isFileAttached;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isFileAttached ? Colors.green[50] : Colors.grey[100],
                          border: Border.all(color: isFileAttached ? Colors.green : Colors.grey),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(isFileAttached ? Icons.check_circle : Icons.camera_alt,
                                color: isFileAttached ? Colors.green : Colors.grey[700]),
                            const SizedBox(width: 8),
                            Text(
                              isFileAttached ? "Medical Certificate Attached" : "Attach Photo / Medical Cert",
                              style: TextStyle(
                                  color: isFileAttached ? Colors.green : Colors.grey[700],
                                  fontWeight: FontWeight.bold
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text("Cancel")),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(backgroundColor: kalgidharBlue),
                  onPressed: () {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Application sent to $selectedRecipient")));
                  },
                  child: const Text("Submit", style: TextStyle(color: Colors.white)),
                )
              ],
            );
          },
        );
      },
    );
  }

  // ==========================================
  // HELPERS (Leave Status, Message Center, Cards)
  // ==========================================

  void _showLeaveStatusSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        return Container(
          padding: const EdgeInsets.all(20),
          height: MediaQuery.of(context).size.height * 0.6,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Leave Application Status", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kalgidharBlue)),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  itemCount: leaveHistory.length,
                  itemBuilder: (ctx, i) {
                    var item = leaveHistory[i];
                    Color statusColor;
                    IconData statusIcon;

                    if (item['status'] == 'Approved') {
                      statusColor = Colors.green;
                      statusIcon = Icons.check_circle_outline;
                    } else if (item['status'] == 'Rejected') {
                      statusColor = Colors.red;
                      statusIcon = Icons.cancel_outlined;
                    } else {
                      statusColor = Colors.orange;
                      statusIcon = Icons.hourglass_empty;
                    }

                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      elevation: 2,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(item['date']!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(color: statusColor.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                                  child: Row(
                                    children: [
                                      Icon(statusIcon, size: 14, color: statusColor),
                                      const SizedBox(width: 4),
                                      Text(item['status']!, style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12)),
                                    ],
                                  ),
                                )
                              ],
                            ),
                            const Divider(),
                            Row(children: [
                              const Text("Reason: ", style: TextStyle(fontWeight: FontWeight.bold)),
                              Text(item['reason']!),
                            ]),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        );
      },
    );
  }

  void _showAttendanceLogSheet(BuildContext context, String subjectName) {
    List<Map<String, String>> logs = attendanceLogs[selectedSubjectCode] ?? [];
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("$subjectName Attendance", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kalgidharBlue)),
            const Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: logs.length,
                itemBuilder: (ctx, i) => ListTile(
                  title: Text(logs[i]['date']!),
                  trailing: Text(logs[i]['status']!, style: TextStyle(fontWeight: FontWeight.bold, color: logs[i]['status'] == 'Present' ? Colors.green : Colors.red)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTestLogSheet(BuildContext context, String subjectName, List<Map<String, dynamic>> tests) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("$subjectName Scores", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
            const Divider(),
            Expanded(
              child: ListView.builder(
                itemCount: tests.length,
                itemBuilder: (ctx, i) => ListTile(
                  title: Text(tests[i]['test']),
                  trailing: Text("${tests[i]['score']} / 17", style: const TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showMessageCenter(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (ctx) => Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Text("Faculty Messages", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: kalgidharBlue)),
                const Divider(),
                Expanded(child: ListView.builder(
                  itemCount: facultyMessages.length,
                  itemBuilder: (c, i) => ListTile(
                    leading: Icon(Icons.mail, color: kalgidharBlue),
                    title: Text(facultyMessages[i]['title']!),
                    subtitle: Text(facultyMessages[i]['sender']!),
                    trailing: Text(facultyMessages[i]['priority']!, style: const TextStyle(color: Colors.red, fontSize: 10)),
                  ),
                ))
              ],
            )
        )
    );
  }

  Widget _buildSectionTitle(String title) => Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold));

  Widget _buildAttendanceCard(String title, String subtitle, double percentage, int attended, int total, bool isOverall) {
    Color color = isOverall ? kalgidharBlue : (percentage < 0.75 ? Colors.redAccent : Colors.green);
    return Card(
      elevation: 3, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(children: [
          Stack(alignment: Alignment.center, children: [
            SizedBox(height: 70, width: 70, child: CircularProgressIndicator(value: percentage, strokeWidth: 8, backgroundColor: Colors.grey[200], valueColor: AlwaysStoppedAnimation(color))),
            Text('${(percentage * 100).toInt()}%', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color)),
          ]),
          const SizedBox(width: 20),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            if (!isOverall) Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            Text("$attended / $total Attended", style: const TextStyle(fontWeight: FontWeight.w500)),
          ]),
        ]),
      ),
    );
  }

  Widget _buildTestPerformanceCard(String name, double avg, double pct) {
    return Card(
      elevation: 3, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(children: [
          Stack(alignment: Alignment.center, children: [
            SizedBox(height: 70, width: 70, child: CircularProgressIndicator(value: pct, strokeWidth: 8, backgroundColor: Colors.grey[200], valueColor: const AlwaysStoppedAnimation(Colors.deepPurple))),
            Text(avg.toStringAsFixed(1), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.deepPurple)),
          ]),
          const SizedBox(width: 20),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text("Monday Test (Max 17)", style: TextStyle(fontWeight: FontWeight.bold)),
            Text(name, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ]),
        ]),
      ),
    );
  }
}